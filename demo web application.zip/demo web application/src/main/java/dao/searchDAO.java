package dao;

import model.Alarm;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class searchDAO {
    public  static void main(String[] args) {
        String connectionUrl = "jdbc:sqlserver://FS-18576\\SQLEXPRESS;databaseName=ModuleAssembly;integratedSecurity=true";

        try (Connection con = DriverManager.getConnection(connectionUrl); Statement stmt = con.createStatement();) {
            String SQL = "SELECT TOP 10 * FROM ModuleAssembly.dbo.AlarmName where AlarmName.Name LIKE '%Stop%'";
            ResultSet rs = stmt.executeQuery(SQL);
            ArrayList<Alarm> alarmList = new ArrayList<>();
            while (rs.next()) {
                System.out.println(rs.getString("AlarmNameId") + " " + rs.getString("EquipmentId")  + " " + rs.getString("AlarmId")  + " " + rs.getString("Name"));
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
