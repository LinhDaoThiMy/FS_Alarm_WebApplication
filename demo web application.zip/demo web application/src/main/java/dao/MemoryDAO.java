package dao;

import model.Alarm;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MemoryDAO {
    List<Alarm> listOfAlarm = new ArrayList<>();

    public MemoryDAO (){
        this.listOfAlarm = new ArrayList<>();
    }

    public void addNewAlarm(Alarm alarm){
        this.listOfAlarm.add(alarm);
    }

    public List<Alarm> getListOfAlarm(){
        return listOfAlarm;
    }

    public void setListOfAlarm(List<Alarm> listOfAlarm) {
        this.listOfAlarm = listOfAlarm;
    }

    public void deleteAlarm(String id){
        List<Alarm> results = new ArrayList<Alarm>();
        for (Alarm a: this.getListOfAlarm()) {
            if(!a.getAlarmID().equalsIgnoreCase(id)){
                results.add(a);
            }
        }
        this.setListOfAlarm(results);
    }

    public Alarm findAlarmByID(String id) {
        for (Alarm a:this.getListOfAlarm()) {
            if(a.getAlarmID().equalsIgnoreCase(id)){
                return a;
            }
        }
        return new Alarm();
    }

    public void updateAlarm(Alarm alarm) {
        List<Alarm> results = new ArrayList<>();
        for (Alarm a: this.getListOfAlarm()) {
            if(a.getAlarmID().equalsIgnoreCase(alarm.getAlarmID())){
                results.add(alarm);
            }else{
                results.add(a);
            }
        }
        this.setListOfAlarm(results);
    }

}
