package dao;

import model.Alarm;

import java.util.ArrayList;
import java.util.List;

public class AlarmDAO {
    public static List<Alarm> listAlarms(){
        List<Alarm> list = new ArrayList<>();

        Alarm a1 = new Alarm("493", "19941", "0", "P00_General.AlarmsSSP.SSP[0]: General - Tool Leakage Active");
        Alarm a2 = new Alarm("493", "19941", "1", "P00_General.AlarmsSSP.SSP[0]: General - Tool Leakage Active");
        Alarm a3 = new Alarm("493", "19941", "2", "P00_General.AlarmsSSP.SSP[0]: General - Tool Leakage Active");
        Alarm a4 = new Alarm("493", "19941", "3", "P00_General.AlarmsSSP.SSP[0]: General - Tool Leakage Active");
        list.add(a1);
        list.add(a2);
        list.add(a3);
        list.add(a4);
        return list;
    }
}
