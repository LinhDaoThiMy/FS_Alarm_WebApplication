package dao;

import model.Alarm;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.filter.ShallowEtagHeaderFilter;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OptionalDataException;
import java.util.ArrayList;
import java.util.List;


public class ExportExcelFile {

    public static List <Alarm> alarms = new ArrayList<>();

    private static String[] columns = { "Alarm Name ID", "Equipment ID", "Alarm ID", "Name" };

    private static HSSFCellStyle createStyleForTitle(HSSFWorkbook workbook){
        HSSFFont font = workbook.createFont();
        font.setBold(true);
        HSSFCellStyle style = workbook.createCellStyle();
        style.setFont(font);
        return style;
    }

    public static void main(String[] args) throws IOException {

        alarms.add(new Alarm("493", "19941", "0", "P_00"));
        alarms.add(new Alarm("494", "19941", "1", "P_01"));
        alarms.add(new Alarm("494", "19941", "2", "P_02"));

        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Alarms");

        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setFontHeightInPoints((short) 14);
        headerFont.setColor(IndexedColors.RED.getIndex());

        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFont(headerFont);

        Row headerRow = sheet.createRow(0);

        for(int i = 0; i< columns.length; i++){
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(columns[i]);
            cell.setCellStyle(headerCellStyle);
        }

        int rowNum = 1;

        for(Alarm alarm:alarms){
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(alarm.getAlarmNameId());
            row.createCell(1).setCellValue(alarm.getEquipmentID());
            row.createCell(2).setCellValue(alarm.getAlarmID());
            row.createCell(3).setCellValue(alarm.getName());
        }

        for(int i=0; i<columns.length; i++){
            sheet.autoSizeColumn(i);
        }

        FileOutputStream fs = new FileOutputStream("export.xlsx");
        workbook.write(fs);
        fs.close();
    }

}
