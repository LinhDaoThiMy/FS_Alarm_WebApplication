package dao;

import model.Alarm;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;


public class testDAO {

    public static void main(String[] args) throws SQLException {
        dialogTest();
    }

    private void deleteBtnActionPerformed(java.awt.event.ActionEvent evt){
        int opt = JOptionPane.showConfirmDialog(null, "Are you sure to delete", "Delete", JOptionPane.YES_NO_OPTION);
        if(opt == 0){
            try{
                String url = "jdbc:sqlserver://FS-18576\\SQLEXPRESS;databaseName=ModuleAssembly;integratedSecurity=true";
                Connection conn = DriverManager.getConnection(url);

            } catch (Exception e){
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }

    public static void connectSQLServerExpress() throws SQLException {
        String connectionUrl = "jdbc:sqlserver://FS-18576\\SQLEXPRESS;databaseName=LocalTest;integratedSecurity=true";

        Connection con = DriverManager.getConnection(connectionUrl);
        Statement statement = con.createStatement();
        String SQL = "select * from LocalTest.dbo.AlarmName";
        ResultSet result = statement.executeQuery(SQL);
        while (result.next()){
            System.out.println(result.getString("AlarmNameId") + "," + result.getString("EquipmentId") + "," + result.getString("AlarmId") + "," + result.getString("Name"));
        }
    }

    public static  void testConnectNewDatabase() throws SQLException {
        String connectionURL = "jdbc:sqlserver://FS-18576\\SQLEXPRESS;databaseName=LocalTest;integratedSecurity=true";

        Connection con = DriverManager.getConnection(connectionURL);
        Statement stmt = con.createStatement();
        String sql = "SELECT * from LocalTest.dbo.AlarmName";
        ResultSet rs = stmt.executeQuery(sql);

        while (rs.next()){
            System.out.println(rs.getString("AlarmId"));
        }
    }

    public static void CreateDialog(){
        final JFrame parent = new JFrame();
        JButton button = new JButton();

        button.setText("Click me to show dialog");
        parent.add(button);
        parent.pack();
        parent.setVisible(true);

        button.addActionListener(new java.awt.event.ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = JOptionPane.showInputDialog(parent, "What is your name?", null);
            }
        });
    }

    public static void connect() {
        Connection conn = null;
        Statement stmt = null;
        try {
            // db parameters
            String url = "jdbc:sqlite:C:/sqlite/testDB.db";
            // create a connection to the database
            conn = DriverManager.getConnection(url);
            conn.setAutoCommit(false);
            System.out.println("Connection to SQLite has been established.");
            stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery( "SELECT * FROM ALARMSQLITE;" );
//            String sqlite = "CREATE TABLE ALARMSQLITE" +
//                            "(ALARM_NAME_ID     TEXT    NOT NULL," +
//                            " EQUIPMENT_ID      TEXT    NOT NULL, " +
//                            " NAME              TEXT    NOT NULL, " +
//                            " ALARM_ID          TEXT    NOT NULL)";
//            String sqlite = "INSERT INTO ALARMSQLITE (ALARM_NAME_ID,EQUIPMENT_ID,NAME,ALARM_ID) " +
//                                "VALUES ('493', '19941', '1', 'P00_General Alarm');";
//            stmt.executeUpdate(sqlite);
//            stmt.close();
//            conn.commit();
//            conn.close();
            while ( rs.next() ) {
                String alarmNameId = rs.getString("ALARM_NAME_ID");
                String equipment_Id = rs.getString("EQUIPMENT_ID");
                String  name = rs.getString("NAME");
                String  alarm_Id = rs.getString("ALARM_ID");

                System.out.println( "ALARM_NAME_ID = " + alarmNameId );
                System.out.println( "EQUIPMENT_ID = " + equipment_Id );
                System.out.println( "NAME = " + name );
                System.out.println( "ALARM_ID = " + alarm_Id );
                System.out.println();
            }
            rs.close();
            stmt.close();
            conn.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
            System.exit(0);
        }
        System.out.println("Table created successfully");
    }

    public static void dialogTest(){
        ImageIcon icon = new ImageIcon("E −\\new.PNG");
        JPanel panel = new JPanel();
        panel.setSize(new Dimension(250, 100));
        panel.setLayout(null);
//            JLabel label1 = new JLabel("The file may contain virus.");
//            label1.setVerticalAlignment(SwingConstants.BOTTOM);
//            label1.setBounds(20, 20, 200, 30);
//            label1.setHorizontalAlignment(SwingConstants.CENTER);
//            panel.add(label1);
        JLabel label2 = new JLabel("Do you still want to delete it?");
        label2.setVerticalAlignment(SwingConstants.TOP);
        label2.setHorizontalAlignment(SwingConstants.CENTER);
        label2.setBounds(20, 80, 200, 20);
        panel.add(label2);
        UIManager.put("OptionPane.minimumSize", new Dimension(400, 200));
        int res = JOptionPane.showConfirmDialog(null, panel, "Dialog",
                JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE, icon);
        if(res == 0) {
            System.out.println("Pressed YES");
        } else if (res == 1) {
            System.out.println("Pressed NO");
        } else {
            System.out.println("Pressed CANCEL");
        }

    }

}
