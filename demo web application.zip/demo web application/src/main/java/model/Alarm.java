package model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class Alarm {
    @NotNull(message = "Alarm Name ID is required")
    @Size(min = 1, message = "Alarm Name ID cannot be null")
    private String alarmNameId;

    @NotNull(message = "Equipment ID is required")
    @Size(min = 1, message = "Equipment ID cannot be null")
    private String equipmentID;

    @NotNull(message = "Alarm ID is required")
    @Size(min = 1, message = "Alarm ID cannot be null")
    private String alarmID;

    @NotNull(message = "Name is required")
    @Size(min = 1, message = "Name cannot be null")
    private String name;

    public Alarm() {
    }

    public Alarm(String alarmNameId, String equipmentID, String alarmID, String name){
        this.alarmNameId = alarmNameId;
        this.equipmentID = equipmentID;
        this.alarmID = alarmID;
        this.name = name;
    }

    public String getAlarmNameId() {
        return alarmNameId;
    }

    public void setAlarmNameId(String alarmNameId) {
        this.alarmNameId = alarmNameId;
    }

    public String getEquipmentID() {
        return equipmentID;
    }

    public void setEquipmentID(String equipmentID) {
        this.equipmentID = equipmentID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAlarmID() {
        return alarmID;
    }

    public void setAlarmID(String alarmID) {
        this.alarmID = alarmID;
    }

    @Override
    public String toString() {
        return this.getAlarmNameId() + "-" + this.getEquipmentID() + "-" + this.getAlarmID() + "-" + this.getName();
    }
}
