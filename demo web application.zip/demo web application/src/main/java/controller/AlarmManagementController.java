package controller;

import dao.MemoryDAO;
import model.Alarm;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

@Controller

public class AlarmManagementController {

    MemoryDAO memoryDAO;

    public AlarmManagementController(){
        this.memoryDAO = new MemoryDAO();
    }

    @RequestMapping(value = "/homePage", method = RequestMethod.GET)
    public String homePage(){
        return "home_page";
    }

//    @RequestMapping(value = "/searchAlarm", method = RequestMethod.GET)
//    public String searchPage(){
//        return "search_page";
//    }

    @RequestMapping(value = "/alarmManagement", method = RequestMethod.GET)
    public String showAlarmManagement(Model model){

        model.addAttribute("alarm", new Alarm());
        return "fs_alarm_list";
    }

    @RequestMapping(value = "/addNewAlarm", method = RequestMethod.POST)
    public String addNewAlarm(@Valid@ModelAttribute("alarm")Alarm alarm, BindingResult bindingResult, Model model){
        if(bindingResult.hasErrors()){
        } else {
            System.out.println(alarm);
            memoryDAO.addNewAlarm(alarm);
            model.addAttribute("alarm", new Alarm());
        }
        model.addAttribute("listOfAlarm", memoryDAO.getListOfAlarm());
        return "fs_alarm_list";
    }


    @RequestMapping(value = "/deleteAlarm", method = RequestMethod.GET)
    public String deleteAlarm(HttpServletRequest request, Model model){
        String id = request.getParameter("id");

        memoryDAO.deleteAlarm(id);

        model.addAttribute("alarm", new Alarm());

        model.addAttribute("listOfAlarm", memoryDAO.getListOfAlarm());
        return "fs_alarm_list";
    }

    @RequestMapping(value = "/updateAlarm/{id}", method = RequestMethod.GET)
    public String updateAlarm(@PathVariable String id, Model model){
        Alarm alarm = memoryDAO.findAlarmByID(id);

        model.addAttribute("alarm", alarm);

        model.addAttribute("listOfAlarm", memoryDAO.getListOfAlarm());
        return "fs_alarm_list";
    }

    @RequestMapping(value = "/modifyAlarm", method = RequestMethod.POST)
    public String modifyAlarm(@ModelAttribute("alarm") Alarm alarm, Model model){
        memoryDAO.updateAlarm(alarm);

        model.addAttribute("alarm", alarm);

        model.addAttribute("listOfAlarm", memoryDAO.getListOfAlarm());

        return "fs_alarm_list";
    }
    
}
